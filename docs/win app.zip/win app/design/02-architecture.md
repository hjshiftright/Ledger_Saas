# Ledger Desktop — System Architecture

**Version:** 1.0  
**Status:** Design Review

---

## 1. Process Model

Ledger Desktop runs as a **single Windows process**. There is no separate server process, no background service daemon, and no subprocess to manage at runtime (except the isolated cracker process, which is spawned on demand and killed after 30 seconds).

```
┌──────────────────────────────────────────────────────────┐
│              Ledger.exe  (Single .NET 9 Process)          │
│                                                            │
│  ┌─────────────────────┐   ┌───────────────────────────┐ │
│  │   WPF Shell Thread   │   │   ASP.NET Core IHost      │ │
│  │  MainWindow.xaml     │   │   (Kestrel on localhost)  │ │
│  │  WebView2 (Chromium) │◄──┤   Endpoints + SignalR Hub │ │
│  │  System Tray         │   │   Background Services     │ │
│  │  PinLockScreen.xaml  │   └──────────────┬────────────┘ │
│  └─────────────────────┘                  │               │
│                                    Thread Pool            │
│                          ┌───────────────────────────┐   │
│                          │  IHostedService workers:   │   │
│                          │  FileWatcherService        │   │
│                          │  ProcessingQueueService    │   │
│                          │  VaultSyncService          │   │
│                          └───────────────────────────┘   │
└──────────────────────────────────────────────────────────┘

  ┌──────────────────────────────────────────┐
  │  Ledger.Shell.CrackerProcess.exe          │
  │  (Spawned on demand, sandboxed, no net)  │
  │  Named pipe IPC ↔ parent process         │
  │  Kill timeout: 30 seconds                │
  └──────────────────────────────────────────┘

  ┌──────────────────────────────────────────┐
  │  Ledger.ShellExtension.dll (COM in-proc) │
  │  Loaded by Windows Explorer process      │
  │  Read-only SQLite connection (no writes) │
  └──────────────────────────────────────────┘
```

### Why Single Process?
- Simpler MSIX packaging (one executable)
- No IPC complexity between shell and API
- EF Core + services share a single DI container
- WPF dispatcher and Kestrel coexist via `IHost` hosting model

---

## 2. Component Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                         Ledger.Shell (WPF)                          │
│                                                                      │
│  App.xaml.cs ──► IHost.StartAsync() ──► binds random localhost port │
│  MainWindow.xaml ──► WebView2 navigates to http://localhost:{port}/  │
│  LedgerBridge.cs ──► window.__ledger.* JS bridge                    │
│  AntiTamperGuard.cs (RELEASE) ──► anti-debug, no-inject             │
│  PinLockScreen.xaml ──► Argon2id PIN gate (if PIN enabled)          │
└───────────────────────────┬─────────────────────────────────────────┘
                            │ IHost (in-process)
┌───────────────────────────▼─────────────────────────────────────────┐
│                       Ledger.Api (ASP.NET Core 9)                   │
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │ Endpoint Groups (Minimal API)                                │   │
│  │  SetupEndpoints  ProfileEndpoints  FilesEndpoints            │   │
│  │  AccountsEndpoints  TransactionsEndpoints  ProposalsEndpoints│   │
│  │  ReportsEndpoints  BudgetsEndpoints  GoalsEndpoints          │   │
│  │  ChatEndpoints  SettingsEndpoints  FamilyEndpoints(v2)       │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                      │
│  ┌───────────────────┐  ┌──────────────────────────────────────┐   │
│  │  FileStatusHub     │  │  Background Services                 │   │
│  │  (SignalR)         │  │  FileWatcherService (FileSystemWatch)│   │
│  │  Events:           │  │  ProcessingQueueService (SemaphoreS.)│   │
│  │  file.detected     │  │  VaultSyncService (deletion handler) │   │
│  │  file.parsing      │  └──────────────────────────────────────┘   │
│  │  file.proposed     │                                              │
│  │  file.organized    │       wwwroot/ → React 19 production build  │
│  │  file.failed       │       Served as static files                │
│  │  file.pw_required  │                                              │
│  │  file.rm_confirm   │                                              │
│  └───────────────────┘                                              │
└───────────────────────────┬─────────────────────────────────────────┘
                            │ DI Container
┌───────────────────────────▼─────────────────────────────────────────┐
│                     Ledger.Infrastructure                           │
│                                                                      │
│  Database/                   Security/                              │
│    LedgerDbContext             DatabaseKeyProvider (SQLCipher)       │
│    DbConnectionInterceptor     FieldEncryptor (AES-256-GCM)         │
│    FieldEncryptor              PinVaultService (Argon2id + DPAPI)   │
│    Migrations/                 SecureMemory (pinned byte arrays)     │
│                                PasswordCrackerService (child proc)  │
│  FileSystem/                                                         │
│    LedgerDriveManager        LLM/                                   │
│    VaultManager                ILlmProvider                         │
│    FileOrganizerService        GeminiProvider                       │
│                                OpenAIProvider                       │
│  Parsing/                      AnthropicProvider                    │
│    FileDetectorService         PrivacyTransformer                   │
│    OcrEngine (dual)                                                  │
│    Pdf/ (15+ bank parsers)   Notifications/                         │
│    Csv/ (7+ parsers)           ToastService                         │
│                                                                      │
│  Services/                   WindowsSearch/                         │
│    NormalizerService           SearchIndexService                   │
│    DeduplicationService        SearchPropertyWriter                 │
│    CategorizationService                                             │
│    ProposalService                                                   │
└───────────────────────────┬─────────────────────────────────────────┘
                            │ EF Core 9
┌───────────────────────────▼─────────────────────────────────────────┐
│             SQLite + SQLCipher 4.6                                  │
│   Key = PBKDF2(MachineGuid + salt, 200k iter, SHA-256)             │
│        + optional Argon2id PIN factor                               │
│   Path: %AppData%\Roaming\LedgerApp\data\ledger.db                 │
└─────────────────────────────────────────────────────────────────────┘
                            │ Read-only mirror for Shell Extension
┌───────────────────────────▼─────────────────────────────────────────┐
│             Ledger.ShellExtension (COM DLL, Explorer-hosted)        │
│   LedgerOverlayHandler → reads FileRegistry.ShellOverlayState      │
│   LedgerContextMenu → "Add to LedgerDrive", "View in Ledger"       │
│   SearchPropertyHandler → writes IPropertyStore on organized files  │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 3. Project Layout

```
Ledger.Desktop.sln
├── Ledger.Shell/                    net9.0-windows (WPF)
│   ├── App.xaml.cs                  IHost startup, singleton mutex
│   ├── MainWindow.xaml(.cs)         WebView2 host
│   ├── PinLockScreen.xaml(.cs)      PIN overlay WPF window
│   ├── SplashScreen.xaml(.cs)       Loading splash while Kestrel starts
│   ├── TrayIcon.cs                  System.Windows.Forms.NotifyIcon
│   ├── Security/
│   │   └── AntiTamperGuard.cs
│   └── Bridge/
│       └── LedgerBridge.cs          COM-visible bridge object
│
├── Ledger.Api/                      net9.0
│   ├── Program.cs                   IHostBuilder, DI, middleware
│   ├── Features/
│   │   ├── SetupEndpoints.cs
│   │   ├── ProfileEndpoints.cs
│   │   ├── FilesEndpoints.cs
│   │   ├── AccountsEndpoints.cs
│   │   ├── TransactionsEndpoints.cs
│   │   ├── ProposalsEndpoints.cs
│   │   ├── ReportsEndpoints.cs
│   │   ├── BudgetsEndpoints.cs
│   │   ├── GoalsEndpoints.cs
│   │   ├── ChatEndpoints.cs
│   │   ├── SettingsEndpoints.cs
│   │   └── FamilyEndpoints.cs       (stub in v1, implemented v2)
│   ├── Hubs/
│   │   └── FileStatusHub.cs
│   ├── Background/
│   │   ├── FileWatcherService.cs
│   │   ├── ProcessingQueueService.cs
│   │   └── VaultSyncService.cs
│   └── wwwroot/                     React production build (at build time)
│
├── Ledger.Domain/                   net9.0 (no framework deps)
│   ├── Entities/                    All EF Core entity classes
│   │   ├── UserProfile.cs
│   │   ├── FamilyMember.cs          (v1: seeded with Self record)
│   │   ├── FileRegistry.cs
│   │   ├── ProcessingQueueItem.cs
│   │   ├── Account.cs
│   │   ├── Transaction.cs
│   │   ├── TransactionLine.cs
│   │   ├── ImportBatch.cs
│   │   └── ... (25+ entities)
│   ├── Enums/
│   │   ├── ProcessingStatus.cs
│   │   ├── ShellOverlayState.cs
│   │   ├── FamilyRelationship.cs
│   │   └── ...
│   └── Interfaces/
│       ├── IDocumentParser.cs
│       ├── ILlmProvider.cs
│       └── IBackgroundTaskQueue.cs
│
├── Ledger.Infrastructure/           net9.0
│   ├── Database/
│   │   ├── LedgerDbContext.cs
│   │   ├── DatabaseKeyProvider.cs
│   │   ├── DbConnectionInterceptor.cs
│   │   ├── FieldEncryptor.cs
│   │   └── Migrations/
│   ├── Security/
│   │   ├── PinVaultService.cs
│   │   ├── SecureMemory.cs
│   │   └── PasswordCrackerService.cs
│   ├── FileSystem/
│   │   ├── LedgerDriveManager.cs
│   │   ├── VaultManager.cs
│   │   └── FileOrganizerService.cs
│   ├── Parsing/
│   │   ├── FileDetectorService.cs
│   │   ├── Ocr/
│   │   │   └── OcrEngine.cs
│   │   ├── Pdf/
│   │   │   ├── HdfcPdfParser.cs
│   │   │   ├── SbiPdfParser.cs
│   │   │   ├── IciciPdfParser.cs
│   │   │   ├── AxisPdfParser.cs
│   │   │   ├── KotakPdfParser.cs
│   │   │   ├── IdfcPdfParser.cs
│   │   │   ├── UnionPdfParser.cs
│   │   │   ├── IndusIndPdfParser.cs
│   │   │   ├── YesCcPdfParser.cs
│   │   │   ├── HdfcCcPdfParser.cs
│   │   │   ├── IciciCcPdfParser.cs
│   │   │   └── CasCamsParser.cs
│   │   └── Csv/
│   │       ├── GenericCsvParser.cs
│   │       ├── HdfcCsvParser.cs
│   │       ├── SbiCsvParser.cs
│   │       ├── IciciCsvParser.cs
│   │       ├── AxisCsvParser.cs
│   │       ├── KotakCsvParser.cs
│   │       └── ZerodhaCsvParser.cs
│   ├── Services/
│   │   ├── NormalizerService.cs
│   │   ├── DeduplicationService.cs
│   │   ├── CategorizationService.cs
│   │   └── ProposalService.cs
│   ├── LLM/
│   │   ├── ILlmProvider.cs
│   │   ├── GeminiProvider.cs
│   │   ├── OpenAIProvider.cs
│   │   ├── AnthropicProvider.cs
│   │   └── PrivacyTransformer.cs
│   ├── Notifications/
│   │   └── ToastService.cs
│   └── WindowsSearch/
│       ├── SearchIndexService.cs
│       └── SearchPropertyWriter.cs
│
├── Ledger.Shell.CrackerProcess/     net9.0 (sandboxed exe)
│   └── Program.cs
│
├── Ledger.ShellExtension/           net9.0-windows (COM DLL)
│   ├── LedgerOverlayHandler.cs
│   ├── LedgerContextMenu.cs
│   └── SearchPropertyHandler.cs
│
├── Ledger.Shell.Package/            Windows Application Packaging Project
│   ├── Package.appxmanifest
│   └── Assets/
│
└── Ledger.Tests/                    net9.0 (xUnit 2.9)
    ├── Parsing/
    ├── Security/
    ├── Services/
    └── Fixtures/
```

---

## 4. Startup Sequence

```
1. App.xaml.cs: Application.OnStartup()
   ├── Acquire Global\LedgerApp mutex
   │     └── If fails: activate existing window via named pipe → exit
   ├── Show SplashScreen.xaml (WPF, non-WebView2)
   ├── Build IHost:
   │     ├── Register all DI services (Infrastructure, Api)
   │     ├── EF Core database migration (Database.MigrateAsync)
   │     ├── Seed default COA if first run
   │     └── Bind Kestrel on random ephemeral port
   ├── IHost.StartAsync():
   │     ├── FileWatcherService.StartAsync() → begins watching LedgerDrive
   │     ├── ProcessingQueueService.StartAsync() → resumes pending queue items
   │     └── VaultSyncService.StartAsync() → watches for deletions
   ├── AntiTamperGuard.Check() (RELEASE)
   ├── If PinEnabled:
   │     └── Show PinLockScreen.xaml → block until correct PIN
   ├── Create MainWindow → init WebView2 environment
   ├── Poll GET /health every 500ms
   └── On 200: navigate WebView2 to http://localhost:{port}/

2. React App loads:
   ├── Calls GET /setup/status
   │     └── If SetupComplete=false → show QuickStartWizard
   │     └── If SetupComplete=true → navigate to /dashboard
   └── Opens SignalR connection to /hubs/files
```

---

## 5. Data Flow: File Drop to Ledger

```
User drops HDFC_2025_01.pdf into LedgerDrive\

FileSystemWatcher.Created event
  └── FileWatcherService (debounce 2.5s)
        └── VaultManager.CopyToVaultAsync()
              └── Compute SHA-256
              └── Check FileRegistry for duplicate → skip if found
              └── Copy → .stash\2025-01\HDFC_2025_01.pdf
              └── INSERT FileRegistry { Hash, OriginalName, Status=Stashed }
        └── Enqueue ProcessingQueueItem

ProcessingQueueService (semaphore max 2)
  └── Stage 1: DETECT
        └── FileDetectorService.DetectAsync()
              → DetectionResult { BankName=HDFC, Confidence=0.95, IsEncrypted=false }
        └── SignalR: file.detected
  └── Stage 2: PARSE
        └── ParserRegistry.GetParser(HDFC_PDF) → HdfcPdfParser
        └── HdfcPdfParser.ParseAsync(stream)
              → ExtractionChain: TextLayer → Tables → (OCR if needed)
        └── ParseResult { Rows[120], Confidence=0.97, ExtractionMethod=TextLayer }
        └── SignalR: file.parsing
  └── Stage 3: NORMALIZE
        └── NormalizerService.Normalize(rows)
              → NormalizedTransaction[120]
  └── Stage 4: DEDUPLICATE
        └── DeduplicationService.FindDuplicates(rows)
              → 3 duplicates skipped
  └── Stage 5: CATEGORIZE
        └── CategorizationService.Categorize(rows)
              → Category assigned per row
  └── Stage 6: PROPOSE
        └── ProposalService.Generate(rows)
              → TransactionProposal[117] inserted to DB
        └── SignalR: file.proposed
  └── Stage 7: ORGANIZE
        └── FileOrganizerService.Organize(fileReg)
              → Move to Banks\HDFC\2025\January.pdf
              → Update FileRegistry.OrganizedPath, Status=Organized
        └── SearchPropertyWriter.WriteAsync(organizedPath, metadata)
        └── UPDATE FileRegistry.ShellOverlayState = Done
        └── SignalR: file.organized
        └── Toast: "HDFC Jan 2025 processed — 117 transactions pending review"
```

---

## 6. Dependency Injection Registration

```csharp
// Ledger.Api/Program.cs (simplified)
builder.Services
    // Infrastructure — Database
    .AddDbContext<LedgerDbContext>(opt => opt.UseSqlite())
    .AddSingleton<IDatabaseKeyProvider, DatabaseKeyProvider>()
    .AddSingleton<IFieldEncryptor, FieldEncryptor>()
    // Infrastructure — Security
    .AddSingleton<IPinVaultService, PinVaultService>()
    .AddSingleton<IPasswordCrackerService, PasswordCrackerService>()
    // Infrastructure — File System
    .AddSingleton<ILedgerDriveManager, LedgerDriveManager>()
    .AddSingleton<IVaultManager, VaultManager>()
    .AddSingleton<IFileOrganizerService, FileOrganizerService>()
    // Infrastructure — Parsing
    .AddSingleton<IFileDetectorService, FileDetectorService>()
    .AddSingleton<IOcrEngine, OcrEngine>()
    .AddSingleton<IParserRegistry, ParserRegistry>()
    // -- Individual parsers auto-registered via ParserRegistry scan
    // Infrastructure — Services
    .AddScoped<INormalizerService, NormalizerService>()
    .AddScoped<IDeduplicationService, DeduplicationService>()
    .AddScoped<ICategorizationService, CategorizationService>()
    .AddScoped<IProposalService, ProposalService>()
    // Infrastructure — LLM
    .AddSingleton<ILlmProviderFactory, LlmProviderFactory>()
    .AddSingleton<IPrivacyTransformer, PrivacyTransformer>()
    // Infrastructure — Notifications  
    .AddSingleton<IToastService, ToastService>()
    // Background Services
    .AddHostedService<FileWatcherService>()
    .AddHostedService<ProcessingQueueService>()
    .AddHostedService<VaultSyncService>()
    .AddSingleton<IBackgroundTaskQueue, DefaultBackgroundTaskQueue>()
    // SignalR
    .AddSignalR();
```

---

## 7. Technology Versions (Pinned)

| Package | Version | License |
|---|---|---|
| .NET | 9.0 | MIT |
| ASP.NET Core | 9.0 | MIT |
| EF Core | 9.0.x | MIT |
| SQLitePCLRaw.bundle_e_sqlcipher | 2.1.x | Apache 2 |
| PdfPig | 0.1.9 | MIT |
| Docnet.Core | 2.6.x | Apache 2 |
| Tesseract (.NET) | 5.2.x | Apache 2 |
| CsvHelper | 33.x | MS-PL/Apache 2 |
| ClosedXML | 0.102.x | MIT |
| ML.NET | 3.0.x | MIT |
| SharpShell | 2.7.x | MIT |
| Konscious.Security.Cryptography | 1.3.x | MIT |
| Microsoft.Web.WebView2 | 1.0.x | MS |
| Microsoft.Toolkit.Win32.UI.Notifications | 7.x | MIT |
| Polly | 8.x | BSD-3 |
| xUnit | 2.9.x | Apache 2 |
| Moq | 4.x | BSD-3 |
| FluentAssertions | 7.x | Apache 2 |
